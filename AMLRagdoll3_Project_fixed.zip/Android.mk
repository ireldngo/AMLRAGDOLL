LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := AMLRagdoll
LOCAL_CPP_EXTENSION := .cpp
LOCAL_SRC_FILES := main.cpp mod/logger.cpp mod/config.cpp
LOCAL_C_INCLUDES += $(LOCAL_PATH)/include
LOCAL_CPPFLAGS += -std=c++17 -O2 -DNDEBUG
LOCAL_LDLIBS += -llog
include $(BUILD_SHARED_LIBRARY)
