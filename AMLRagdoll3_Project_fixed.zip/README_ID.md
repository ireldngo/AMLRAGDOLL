# AML Ragdoll 3.0 — kerangka proyek ARM64

Proyek ini adalah kerangka plugin AML, BUKAN plugin ragdoll siap pakai. `main.cpp` hanya mendaftarkan mod dan menulis log; tidak memasang hook game, tidak mengubah memori, dan belum menjalankan fisika.

## Isi
- Header AML dari AndroidModLoader `template_of_mod`
- Header PSDK GTA SA Android dari `aml-psdk`
- Konfigurasi NDK untuk `arm64-v8a`, Android API 24, C++17

## Build
Diperlukan Android NDK yang menyediakan `ndk-build`. Jalankan dari folder ini:

```sh
ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=Android.mk NDK_APPLICATION_MK=Application.mk
```

Hasil modul nantinya bernama `libAMLRagdoll.so` di folder `libs/arm64-v8a/`.

## Status fitur
- [x] Registrasi plugin AML dan konfigurasi Enabled
- [x] Target ABI arm64-v8a
- [ ] Deteksi CPed yang tervalidasi untuk GTA SA 2.10
- [ ] State machine ragdoll dan pemulihan animasi
- [ ] Integrasi physics engine dan collision
- [ ] Uji di perangkat PowerVR / Infinix Hot 30i

Jangan pasang sebagai ragdoll fungsional: build awal ini hanya bootstrap untuk menguji pemuatan AML.
