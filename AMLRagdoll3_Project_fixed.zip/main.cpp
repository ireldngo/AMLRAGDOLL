#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

MYMODCFG(com.vizua.aml.ragdoll, AML Ragdoll 3.0, 0.1, OpenAI)

// Safe bootstrap only. No undocumented game hooks or physics are enabled yet.
// This prevents a placeholder binary from modifying game memory or crashing the game.

extern "C" void OnModLoad()
{
    logger->SetTag("AMLRagdoll");
    logger->Info("AMLRagdoll 3.0 bootstrap loaded");
    const bool enabled = cfg->Bind("Enabled", true)->GetBool();
    delete Config::pLastEntry;
    cfg->Save();
    if (!enabled)
        logger->Info("Plugin disabled in configuration");
    else
        logger->Info("Bootstrap active; ragdoll physics is not implemented yet");
}
